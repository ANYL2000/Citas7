<?php
require_once '../assets/conexion/servidor.php';

session_start();// Iniciando Sesion


if(!isset($_SESSION['login_user_sys'])){

//mysqli_close($conexion); // Cerrando la conexion
echo "<script type='text/javascript'>
      window.location='sesion.php'
      </script>"; // Redirecciona a la pagina de sesion
}

$conexion = connect($host, $port, $db_name, $db_username, $db_password);
$conexion->query("SET NAMES 'utf8'");
$query =$conexion->prepare("SELECT * FROM mostrar_cita;");

$query->execute();
$resultado =$query->fetchAll();


?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

<header>
    <title>Oasis</title>
</header>


<link rel="stylesheet" href="../assets/css/estilo_citas_usuario.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

<?php include 'header_citas.php'; ?>

<div class="btn-group justify-content-right" style="position:relative;margin-left:3vw;top:-5vh;z-index:20;">
<button type="button" class="btn btn-light dropdown-toggle" data-toggle="dropdown"><?php echo $_SESSION['login_user_sys']; ?><span class="caret"></span></button>
<ul class="dropdown-menu" role="menu">
<li><a href="cerrar_sesion.php">Cerrar sesión</a></li>

</ul>
</div>

</head>
<body>
    


<div class="fondo">



<h1 class="titulo_taller">Citas registradas</h1>

<table class="table-responsive">
    <thead>
<tr class="fila_principal">
    <td>Nombre del Especialista</td>
    <td>Nombre de Especialidad</td>
    <td>Fecha</td>
    <td>Hora</td>
    <td>Reservado</td>
</tr>
</thead>
<?php  foreach($resultado as $taller): 

    $hora = $taller['Hora'];

switch($hora){

 case '7': $hora_escrita = "7 am"; break;
 case '8': $hora_escrita = "8 am"; break;
 case '9': $hora_escrita = "9 am"; break;
 case '10': $hora_escrita = "10 am"; break;
 case '11': $hora_escrita = "11 am"; break;
 case '12': $hora_escrita = "12 pm"; break;
 case '13': $hora_escrita = "1 pm"; break;
 case '14': $hora_escrita = "2 pm"; break;
 case '15': $hora_escrita = "3 pm"; break;
 case '16': $hora_escrita = "4 pm"; break;
 case '17': $hora_escrita = "5 pm"; break;
 case '18': $hora_escrita = "6 pm"; break;
 case '19': $hora_escrita = "7 pm"; break;
 case '20': $hora_escrita = "8 pm"; break;
 case '21': $hora_escrita = "9 pm"; break;
 case '22': $hora_escrita = "10 pm"; break;

}

?>

<tr class="filas_secundarias" id="color_gris" >
    <td> <a href="citas2_usuario.php?tallerista=<?php echo ($taller['NombreEspecialista'])?>&taller=<?php echo ($taller['NombreEspecialidad'])?>&calendario=<?php echo $taller['Calendario']?>&hora=<?php echo $taller['Hora']?>"> <?php echo ($taller['NombreEspecialista']);?> </a></td>
    <td> <a href="citas2_usuario.php?tallerista=<?php echo ($taller['NombreEspecialista'])?>&taller=<?php echo ($taller['NombreEspecialidad'])?>&calendario=<?php echo $taller['Calendario']?>&hora=<?php echo $taller['Hora']?>"> <?php echo ($taller['NombreEspecialidad']);?></a></td>
    <!--<td><a href="taller1.2.php?tallerista=<?php //echo utf8_encode($taller['NombreEspecialista'])?>&taller=<?php //echo utf8_encode($taller['NombreEspecialidad'])?>&calendario=<?php //echo $taller['Calendario']?>&turno=<?php //echo $taller['Turno']?>&dia=<?php //echo $taller['Dia']?>"><?php //echo $taller['Calendario']?></a></td>-->
    <td><a href="citas2_usuario.php?tallerista=<?php echo ($taller['NombreEspecialista'])?>&taller=<?php echo ($taller['NombreEspecialidad'])?>&calendario=<?php echo $taller['Calendario']?>&hora=<?php echo $taller['Hora']?>"><?php echo $taller['Calendario']?></a></td>
  
    <td><a href="citas2_usuario.php?tallerista=<?php echo ($taller['NombreEspecialista'])?>&taller=<?php echo ($taller['NombreEspecialidad'])?>&calendario=<?php echo $taller['Calendario']?>&hora=<?php echo $taller['Hora']?>"><?php echo $hora_escrita?></a></td>
    <td><a href="citas2_usuario.php?tallerista=<?php echo ($taller['NombreEspecialista'])?>&taller=<?php echo ($taller['NombreEspecialidad'])?>&calendario=<?php echo $taller['Calendario']?>&hora=<?php echo $taller['Hora']?>"><?php echo $taller['Reservado']?></a></td>
  
    </tr>
</a>

<?php   endforeach; ?>

</table>

</div>

<script
      src="https://code.jquery.com/jquery-3.6.0.min.js"
      integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
      crossorigin="anonymous"
    ></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>


</body>
</html>
<?php $conexion = null;?>